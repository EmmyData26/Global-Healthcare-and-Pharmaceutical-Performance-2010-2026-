/* SQL ANALYSIS: Global Healthcare and Pharmaceutical Industry Analysis:
Trends in Disease Burden, Innovation, and Financial Performance (2010�2026)*/

--Checking Importd Tables
SELECT*FROM biotech_funding$ 
SELECT*FROM clinical_trials$ 
SELECT*FROM disease_burden$ 
SELECT*FROM drug_approvals$ 
SELECT*FROM pharma_companies_financials$ 

--Checking the columns and data types of the tables
EXEC sp_help '[biotech_funding$]';
EXEC sp_help '[clinical_trials$]';
EXEC sp_help '[disease_burden$]';
EXEC sp_help '[drug_approvals$]';
EXEC sp_help '[pharma_companies_financials$]';

-- Altering the Tables for the Year column to be in INT
-- Safely convert the table column type
ALTER TABLE biotech_funding$
ALTER COLUMN year INT;

ALTER TABLE clinical_trials$
ALTER COLUMN year INT;

ALTER TABLE disease_burden$ 
ALTER COLUMN year INT;

ALTER TABLE drug_approvals$
ALTER COLUMN year INT;

ALTER TABLE pharma_companies_financials$ 
ALTER COLUMN year INT;

-- change numeric boolean columns from float to BIT
ALTER TABLE biotech_funding$
ALTER COLUMN is_megadeal BIT;

ALTER TABLE biotech_funding$
ALTER COLUMN is_real_headline BIT;

ALTER TABLE clinical_trials$
ALTER COLUMN is_success BIT;

ALTER TABLE clinical_trials$
ALTER COLUMN is_failure BIT;

ALTER TABLE drug_approvals$
ALTER COLUMN is_blockbuster BIT;

ALTER TABLE drug_approvals$
ALTER COLUMN is_mega_blockbuster BIT;

-- Counting the records accross the tables by rows
SELECT 'Biotech Funding' AS table_name, COUNT(*) AS total_records
FROM [biotech_funding$]

UNION ALL

SELECT 'Clinical Trials', COUNT(*)
FROM [clinical_trials$]

UNION ALL

SELECT 'Disease Burden', COUNT(*)
FROM [disease_burden$]

UNION ALL

SELECT 'Drug Approvals', COUNT(*)
FROM [drug_approvals$]

UNION ALL

SELECT 'Pharma Companies Financials', COUNT(*)
FROM [pharma_companies_financials$];


--Checking the years covered accross each tables
SELECT 
    'Biotech Funding' AS table_name,
    MIN(year) AS first_year,
    MAX(year) AS last_year,
    COUNT(DISTINCT year) AS number_of_years
FROM [biotech_funding$]

UNION ALL

SELECT 
    'Clinical Trials',
    MIN(year),
    MAX(year),
    COUNT(DISTINCT year)
FROM [clinical_trials$]

UNION ALL

SELECT 
    'Disease Burden',
    MIN(year),
    MAX(year),
    COUNT(DISTINCT year)
FROM [disease_burden$]

UNION ALL

SELECT 
    'Drug Approvals',
    MIN(year),
    MAX(year),
    COUNT(DISTINCT year)
FROM [drug_approvals$]

UNION ALL

SELECT 
    'Pharma Companies Financials',
    MIN(year),
    MAX(year),
    COUNT(DISTINCT year)
FROM [pharma_companies_financials$];


--Checking For Duplicate Records
--For Biotech Funding
SELECT 
    deal_id,
    COUNT(*) AS occurrences
FROM [biotech_funding$]
GROUP BY deal_id
HAVING COUNT(*) > 1;
--(Checked, no duplicate)

--For Clinical trials
SELECT 
    trial_id,
    COUNT(*) AS occurrences
FROM [clinical_trials$]
GROUP BY trial_id
HAVING COUNT(*) > 1;
--(Checked, no duplicate)

--For Drug Approvals
SELECT 
    approval_id,
    COUNT(*) AS occurrences
FROM [drug_approvals$]
GROUP BY approval_id
HAVING COUNT(*) > 1;
--(Checked, no duplicate)

--for Pharmaceutical Companies Financials
SELECT 
    company_name,
    year,
    segment,
    COUNT(*) AS occurrences
FROM [pharma_companies_financials$]
GROUP BY 
    company_name,
    year,
    segment
HAVING COUNT(*) > 1;
--(Checked, no duplicates)

