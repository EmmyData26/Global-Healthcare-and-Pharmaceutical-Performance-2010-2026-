--Analysis of Important Categories

--Funding Deal Types
SELECT 
    deal_type,
    COUNT(*) AS deal_count
FROM [biotech_funding$]
GROUP BY deal_type
ORDER BY deal_count DESC;

--Clinical Trial Phases
SELECT 
    phase,
    COUNT(*) AS trial_count
FROM [clinical_trials$]
GROUP BY phase
ORDER BY trial_count DESC;

--Clinical Trial Outcomes
SELECT 
    outcome,
    COUNT(*) AS trial_count
FROM [clinical_trials$]
GROUP BY outcome
ORDER BY trial_count DESC;

--Therapy Areas of Clinical Trials
SELECT 
    therapy_area,
    COUNT(*) AS trial_count
FROM [clinical_trials$]
GROUP BY therapy_area
ORDER BY trial_count DESC;

--Diseases Record Count
SELECT 
    disease,
    COUNT(*) AS record_count
FROM [disease_burden$]
GROUP BY disease
ORDER BY record_count DESC;

--Region's Record Count
SELECT 
    region,
    COUNT(*) AS record_count
FROM [disease_burden$]
GROUP BY region
ORDER BY record_count DESC;

--Drug Type
SELECT 
    drug_type,
    COUNT(*) AS approval_count
FROM [drug_approvals$]
GROUP BY drug_type
ORDER BY approval_count DESC;

--Drug Approval Therapy Areas
SELECT 
    therapy_area,
    COUNT(*) AS approval_count
FROM [drug_approvals$]
GROUP BY therapy_area
ORDER BY approval_count DESC;

