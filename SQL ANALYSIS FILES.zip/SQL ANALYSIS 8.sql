-- ANNUAL COMBINED SUMMARIES
WITH Funding AS
(
    SELECT
        year,

        COUNT(*) AS total_deals,

        SUM(value_usd_bn) 
            AS total_deal_value_usd_bn,

        SUM(
            CASE 
                WHEN is_megadeal = 1 THEN 1 
                ELSE 0 
            END
        ) AS mega_deals,

        SUM(
            CASE 
                WHEN is_megadeal = 1 
                THEN value_usd_bn 
                ELSE 0 
            END
        ) AS mega_deal_value_usd_bn

    FROM [biotech_funding$]

    GROUP BY year
),

Trials AS
(
    SELECT
        year,

        COUNT(*) AS total_trials,

        SUM(
            CASE 
                WHEN is_success = 1 THEN 1 
                ELSE 0 
            END
        ) AS successful_trials,

        SUM(
            CASE 
                WHEN is_success = 1 THEN 1 
                ELSE 0 
            END
        ) * 100.0
        / NULLIF(COUNT(*), 0)
        AS trial_success_rate_pct

    FROM [clinical_trials$]

    GROUP BY year
),

Disease AS
(
    SELECT
        year,

        SUM(dalys_millions)
            AS total_regional_dalys_millions

    FROM [disease_burden$]

    GROUP BY year
),

Approvals AS
(
    SELECT
        year,

        COUNT(*) AS total_approvals,

        SUM(
            CASE 
                WHEN is_blockbuster = 1 THEN 1 
                ELSE 0 
            END
        ) AS blockbuster_approvals

    FROM [drug_approvals$]

    GROUP BY year
),

Companies AS
(
    SELECT
        year,

        SUM(revenue_usd_bn)
            AS total_revenue_usd_bn,

        SUM(operating_income_usd_bn)
            AS total_operating_income_usd_bn,

        SUM(rd_spend_usd_bn)
            AS total_rd_spend_usd_bn,

        SUM(operating_income_usd_bn) * 100.0
            / NULLIF(SUM(revenue_usd_bn), 0)
            AS operating_margin_pct,

        SUM(rd_spend_usd_bn) * 100.0
            / NULLIF(SUM(revenue_usd_bn), 0)
            AS rd_intensity_pct,

        AVG(pipeline_size_est)
            AS average_pipeline_size

    FROM [pharma_companies_financials$]

    GROUP BY year
)

SELECT
    COALESCE(
        Funding.year,
        Trials.year,
        Disease.year,
        Approvals.year,
        Companies.year
    ) AS year,

    Funding.total_deals,
    Funding.total_deal_value_usd_bn,
    Funding.mega_deals,
    Funding.mega_deal_value_usd_bn,

    Trials.total_trials,
    Trials.successful_trials,
    Trials.trial_success_rate_pct,

    Disease.total_regional_dalys_millions,

    Approvals.total_approvals,
    Approvals.blockbuster_approvals,

    Companies.total_revenue_usd_bn,
    Companies.total_operating_income_usd_bn,
    Companies.total_rd_spend_usd_bn,
    Companies.operating_margin_pct,
    Companies.rd_intensity_pct,
    Companies.average_pipeline_size

FROM Funding

FULL OUTER JOIN Trials
    ON Funding.year = Trials.year

FULL OUTER JOIN Disease
    ON COALESCE(
        Funding.year,
        Trials.year
    ) = Disease.year

FULL OUTER JOIN Approvals
    ON COALESCE(
        Funding.year,
        Trials.year,
        Disease.year
    ) = Approvals.year

FULL OUTER JOIN Companies
    ON COALESCE(
        Funding.year,
        Trials.year,
        Disease.year,
        Approvals.year
    ) = Companies.year

ORDER BY year;