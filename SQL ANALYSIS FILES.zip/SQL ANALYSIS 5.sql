-- DISEASE BURDEN ANALYSIS

-- Summary Analysis
SELECT
    COUNT(*) AS total_records,
    COUNT(DISTINCT year) AS years,
    COUNT(DISTINCT region) AS regions,
    COUNT(DISTINCT disease) AS diseases
FROM [disease_burden$];

-- DALYs By Year
SELECT
    year,
    SUM(dalys_millions) AS total_regional_dalys_millions
FROM [disease_burden$]
GROUP BY year
ORDER BY year;

-- DALYs By Disease
SELECT
    disease,
    SUM(dalys_millions) AS total_regional_dalys_millions
FROM [disease_burden$]
GROUP BY disease
ORDER BY total_regional_dalys_millions DESC;

--DALYs Region
SELECT
    region,
    SUM(dalys_millions) AS total_regional_dalys_millions
FROM [disease_burden$]
GROUP BY region
ORDER BY total_regional_dalys_millions DESC;

--Disease By region
SELECT
    disease,
    region,
    SUM(dalys_millions) AS total_dalys_millions
FROM [disease_burden$]
GROUP BY 
    disease,
    region
ORDER BY 
    disease,
    total_dalys_millions DESC;

-- Checking Global DALYs
SELECT
    year,
    disease,
    COUNT(*) AS number_of_rows,
    COUNT(DISTINCT global_dalys_millions) AS distinct_global_values
FROM [disease_burden$]
GROUP BY 
    year,
    disease
ORDER BY 
    year,
    disease;
-- since they're distinct, SUM wouldn't be used for futher analysis, therefore;
--Global DALYs By Year and Disease
SELECT
    year,
    disease,
    MAX(global_dalys_millions) AS global_dalys_millions
FROM [disease_burden$]
GROUP BY
    year,
    disease
ORDER BY
    year,
    disease;

