-- CLINICAL TRIAL ANALYSIS (2010-2026)


--Total Trials
SELECT 
    COUNT(*) AS total_trials
FROM [clinical_trials$];

--Yearly Clinical Trials
SELECT 
    year,
    COUNT(*) AS total_trials
FROM [clinical_trials$]
GROUP BY year
ORDER BY year;

--Clinical Trial Phases
SELECT 
    phase,
    COUNT(*) AS total_trials
FROM [clinical_trials$]
GROUP BY phase
ORDER BY total_trials DESC;

--Clinical Trial Outcomes
SELECT 
    outcome,
    COUNT(*) AS total_trials
FROM [clinical_trials$]
GROUP BY outcome
ORDER BY total_trials DESC;

--Overall Clinical Trials Sucess Rate
SELECT
    COUNT(*) AS total_trials,

    SUM(
        CASE 
            WHEN is_success = 1 THEN 1 
            ELSE 0 
        END
    ) AS successful_trials,

    SUM(
        CASE 
            WHEN is_success = 1 THEN 1 
            ELSE 0 
        END
    ) * 100.0
    / NULLIF(COUNT(*), 0) AS success_rate_pct

FROM [clinical_trials$];

--Clinical Sucess Rates By Phases
SELECT
    phase,
    COUNT(*) AS total_trials,

    SUM(
        CASE 
            WHEN is_success = 1 THEN 1 
            ELSE 0 
        END
    ) AS successful_trials,

    SUM(
        CASE 
            WHEN is_success = 1 THEN 1 
            ELSE 0 
        END
    ) * 100.0
    / NULLIF(COUNT(*), 0) AS success_rate_pct

FROM [clinical_trials$]

GROUP BY phase

ORDER BY success_rate_pct DESC;

--Clinical Trials By Therapy Areas
SELECT 
    therapy_area,
    COUNT(*) AS total_trials
FROM [clinical_trials$]
GROUP BY therapy_area
ORDER BY total_trials DESC;

--Sucess Rate By Therapy Area
SELECT
    therapy_area,
    COUNT(*) AS total_trials,

    SUM(
        CASE 
            WHEN is_success = 1 THEN 1 
            ELSE 0 
        END
    ) AS successful_trials,

    SUM(
        CASE 
            WHEN is_success = 1 THEN 1 
            ELSE 0 
        END
    ) * 100.0
    / NULLIF(COUNT(*), 0) AS success_rate_pct

FROM [clinical_trials$]

GROUP BY therapy_area

ORDER BY success_rate_pct DESC;

--Enrollment and Duration By Phase
SELECT
    phase,
    COUNT(*) AS total_trials,
    AVG(enrollment_n) AS average_enrollment,
    AVG(duration_months) AS average_duration_months
FROM [clinical_trials$]
GROUP BY phase
ORDER BY phase;

--Number of Clinical Trials By Sponsors and Therapy 
SELECT
    sponsor,
    therapy_area,
    COUNT(*) AS total_trials
FROM [clinical_trials$]
GROUP BY
    sponsor,
    therapy_area
ORDER BY
    total_trials DESC;

-- Sponsor and Therapy Area Sucess Rates
SELECT
    sponsor,
    therapy_area,
    COUNT(*) AS total_trials,

    SUM(
        CASE
            WHEN is_success = 1 THEN 1
            ELSE 0
        END
    ) AS successful_trials,

    SUM(
        CASE
            WHEN is_success = 1 THEN 1
            ELSE 0
        END
    ) * 100.0
    / NULLIF(COUNT(*), 0) AS success_rate_pct

FROM [clinical_trials$]

GROUP BY
    sponsor,
    therapy_area

ORDER BY
    total_trials DESC;

-- Top Sponsors For Each Therapy Area
SELECT
    therapy_area,
    sponsor,
    COUNT(*) AS total_trials
FROM [clinical_trials$]
GROUP BY
    therapy_area,
    sponsor
ORDER BY
    therapy_area,
    total_trials DESC;