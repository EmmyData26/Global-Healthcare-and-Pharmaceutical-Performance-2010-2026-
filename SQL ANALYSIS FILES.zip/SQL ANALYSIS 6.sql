-- DRUG APPROVAL ANALYSIS (2010-2026)

-- Total Approvals
SELECT
    COUNT(*) AS total_approvals
FROM [drug_approvals$];

-- Drug Approvals By Years
SELECT
    year,
    COUNT(*) AS total_approvals
FROM [drug_approvals$]
GROUP BY year
ORDER BY year;

--Drug Approvals By Therapy Areas
SELECT
    therapy_area,
    COUNT(*) AS total_approvals
FROM [drug_approvals$]
GROUP BY therapy_area
ORDER BY total_approvals DESC;

--Approval By Drug Types
SELECT
    drug_type,
    COUNT(*) AS total_approvals
FROM [drug_approvals$]
GROUP BY drug_type
ORDER BY total_approvals DESC;

-- Block Buster Approval
SELECT
    COUNT(*) AS total_approvals,

    SUM(
        CASE 
            WHEN is_blockbuster = 1 THEN 1 
            ELSE 0 
        END
    ) AS blockbuster_approvals,

    SUM(
        CASE 
            WHEN is_mega_blockbuster = 1 THEN 1 
            ELSE 0 
        END
    ) AS mega_blockbuster_approvals

FROM [drug_approvals$];

-- Block BUster Rate
SELECT
    SUM(
        CASE 
            WHEN is_blockbuster = 1 THEN 1 
            ELSE 0 
        END
    ) * 100.0
    / NULLIF(COUNT(*), 0) AS blockbuster_rate_pct

FROM [drug_approvals$];

-- Estimated Peak Sales By Therapy area
SELECT
    therapy_area,
    COUNT(*) AS total_approvals,
    AVG(peak_sales_usd_bn_est) AS average_peak_sales_usd_bn,
    SUM(peak_sales_usd_bn_est) AS total_estimated_peak_sales_usd_bn
FROM [drug_approvals$]
GROUP BY therapy_area
ORDER BY total_estimated_peak_sales_usd_bn DESC;

--Top Sponsoring Companies
SELECT TOP 10
    sponsor_company,
    COUNT(*) AS total_approvals,

    SUM(
        CASE 
            WHEN is_blockbuster = 1 THEN 1 
            ELSE 0 
        END
    ) AS blockbuster_approvals,

    SUM(peak_sales_usd_bn_est) AS total_estimated_peak_sales_usd_bn

FROM [drug_approvals$]

GROUP BY sponsor_company

ORDER BY total_approvals DESC;

