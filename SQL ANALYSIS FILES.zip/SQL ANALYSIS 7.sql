-- PHARMA COMPANIES FINANCIAL ANALYSIS (2010-2026)

-- Dataset summary
SELECT
    COUNT(*) AS total_records,
    COUNT(DISTINCT company_name) AS companies,
    COUNT(DISTINCT country_iso3) AS countries,
    COUNT(DISTINCT segment) AS segments,
    COUNT(DISTINCT year ) AS years,
    MAX(year) AS latest_year,
    MIN(year) AS earliest_year
FROM [pharma_companies_financials$];

--Revenue By Year
SELECT
    year,
    SUM(revenue_usd_bn) AS total_revenue_usd_bn
FROM [pharma_companies_financials$]
GROUP BY year
ORDER BY year;

-- Revenue By Company
SELECT
    company_name,
    SUM(revenue_usd_bn) AS total_revenue_usd_bn
FROM [pharma_companies_financials$]
GROUP BY company_name
ORDER BY total_revenue_usd_bn DESC;

-- Revenue By Country
SELECT
    country_iso3,
    SUM(revenue_usd_bn) AS total_revenue_usd_bn
FROM [pharma_companies_financials$]
GROUP BY country_iso3
ORDER BY total_revenue_usd_bn DESC;

-- Revenue By Segment
SELECT
    segment,
    SUM(revenue_usd_bn) AS total_revenue_usd_bn
FROM [pharma_companies_financials$]
GROUP BY segment
ORDER BY total_revenue_usd_bn DESC;

-- Operation Margin By Company
SELECT
    company_name,

    SUM(operating_income_usd_bn) 
        AS total_operating_income_usd_bn,

    SUM(revenue_usd_bn) 
        AS total_revenue_usd_bn,

    SUM(operating_income_usd_bn) * 100.0
        / NULLIF(SUM(revenue_usd_bn), 0)
        AS operating_margin_pct

FROM [pharma_companies_financials$]

GROUP BY company_name

ORDER BY operating_margin_pct DESC;

-- R and D Spending By Company and Country
SELECT
    company_name,  country_iso3,
    SUM(rd_spend_usd_bn) AS total_rd_spend_usd_bn
FROM [pharma_companies_financials$]
GROUP BY company_name,  country_iso3
ORDER BY total_rd_spend_usd_bn DESC;

-- R and D Intensity
SELECT
    company_name,

    SUM(revenue_usd_bn) 
        AS total_revenue_usd_bn,

    SUM(rd_spend_usd_bn) 
        AS total_rd_spend_usd_bn,

    SUM(rd_spend_usd_bn) * 100.0
        / NULLIF(SUM(revenue_usd_bn), 0)
        AS rd_intensity_pct

FROM [pharma_companies_financials$]

GROUP BY company_name

ORDER BY rd_intensity_pct DESC;

-- Pharma Companies Pipeline Size
SELECT
    company_name,
    AVG(pipeline_size_est) AS average_pipeline_size,
    MAX(pipeline_size_est) AS largest_pipeline_size
FROM [pharma_companies_financials$]
GROUP BY company_name
ORDER BY average_pipeline_size DESC;

-- Annual Pharma Company Performance
SELECT
    year,

    SUM(revenue_usd_bn) 
        AS total_revenue_usd_bn,

    SUM(operating_income_usd_bn) 
        AS total_operating_income_usd_bn,

    SUM(rd_spend_usd_bn) 
        AS total_rd_spend_usd_bn,

    SUM(operating_income_usd_bn) * 100.0
        / NULLIF(SUM(revenue_usd_bn), 0)
        AS operating_margin_pct,

    SUM(rd_spend_usd_bn) * 100.0
        / NULLIF(SUM(revenue_usd_bn), 0)
        AS rd_intensity_pct,

    AVG(pipeline_size_est)
        AS average_pipeline_size

FROM [pharma_companies_financials$]

GROUP BY year

ORDER BY year;
