--BIOTECH FUNDING ANALYSIS (2009-2026)


--Total Number of Funding Deals
SELECT 
    COUNT(*) AS total_deals
FROM [biotech_funding$];

--Total Funding Value
SELECT 
    SUM(value_usd_bn) AS total_funding_value_usd_bn
FROM [biotech_funding$];

--Average Deal Value
SELECT 
    AVG(value_usd_bn) AS average_deal_value_usd_bn
FROM [biotech_funding$];

--Annual Funding Performance
SELECT 
    year,
    COUNT(*) AS total_deals,
    SUM(value_usd_bn) AS total_funding_value_usd_bn,
    AVG(value_usd_bn) AS average_deal_value_usd_bn
FROM [biotech_funding$]
GROUP BY year
ORDER BY year;

--Funding Deal Type
SELECT 
    deal_type,
    COUNT(*) AS total_deals,
    SUM(value_usd_bn) AS total_funding_value_usd_bn,
    AVG(value_usd_bn) AS average_deal_value_usd_bn
FROM [biotech_funding$]
GROUP BY deal_type
ORDER BY total_funding_value_usd_bn DESC;

--Mega-deal Analysis
SELECT 
    year,
    COUNT(*) AS mega_deals,
    SUM(value_usd_bn) AS mega_deal_value_usd_bn
FROM [biotech_funding$]
WHERE is_megadeal = 1
GROUP BY year
ORDER BY year;

--Mega-deal Share
SELECT
    SUM(
        CASE 
            WHEN is_megadeal = 1 
            THEN value_usd_bn 
            ELSE 0 
        END
    ) AS mega_deal_value_usd_bn,

    SUM(value_usd_bn) AS total_funding_value_usd_bn,

    SUM(
        CASE 
            WHEN is_megadeal = 1 
            THEN value_usd_bn 
            ELSE 0 
        END
    ) * 100.0
    / NULLIF(SUM(value_usd_bn), 0) AS mega_deal_value_share_pct

FROM [biotech_funding$];

--Top Biiotech Investors or Acquirers
SELECT TOP 10
    acquirer_or_investors,
    COUNT(*) AS total_deals,
    SUM(value_usd_bn) AS total_funding_value_usd_bn
FROM [biotech_funding$]
GROUP BY acquirer_or_investors
ORDER BY total_funding_value_usd_bn DESC;

