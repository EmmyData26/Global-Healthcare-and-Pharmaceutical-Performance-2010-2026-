-- QUERYING THE CREATED TABLE

SELECT *
FROM [Healthcare_and_Pharma_Annuals]
ORDER BY year;

--Number of Years
SELECT
    COUNT(*) AS total_years,
    MIN(year) AS first_year,
    MAX(year) AS last_year
FROM [Healthcare_and_Pharma_Annuals];

--Duplicate Years
SELECT
    year,
    COUNT(*) AS occurrences
FROM [Healthcare_and_Pharma_Annuals]
GROUP BY year
HAVING COUNT(*) > 1;

-- Missing Values
SELECT
    COUNT(*) AS total_rows,

    SUM(
        CASE 
            WHEN total_deals IS NULL 
            THEN 1 
            ELSE 0 
        END
    ) AS missing_funding_years,

    SUM(
        CASE 
            WHEN total_trials IS NULL 
            THEN 1 
            ELSE 0 
        END
    ) AS missing_trial_years,

    SUM(
        CASE 
            WHEN total_regional_dalys_millions IS NULL 
            THEN 1 
            ELSE 0 
        END
    ) AS missing_disease_years,

    SUM(
        CASE 
            WHEN total_approvals IS NULL 
            THEN 1 
            ELSE 0 
        END
    ) AS missing_approval_years,

    SUM(
        CASE 
            WHEN total_revenue_usd_bn IS NULL 
            THEN 1 
            ELSE 0 
        END
    ) AS missing_company_years

FROM [Healthcare_and_Pharma_Annuals];